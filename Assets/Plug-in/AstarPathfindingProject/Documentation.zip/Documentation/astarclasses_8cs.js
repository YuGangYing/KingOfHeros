var astarclasses_8cs =
[
    [ "AstarColor", "class_pathfinding_1_1_astar_color.html", "class_pathfinding_1_1_astar_color" ],
    [ "GraphHitInfo", "struct_pathfinding_1_1_graph_hit_info.html", "struct_pathfinding_1_1_graph_hit_info" ],
    [ "GraphUpdateObject", "class_pathfinding_1_1_graph_update_object.html", "class_pathfinding_1_1_graph_update_object" ],
    [ "IntRect", "struct_pathfinding_1_1_int_rect.html", "struct_pathfinding_1_1_int_rect" ],
    [ "IRaycastableGraph", "interface_pathfinding_1_1_i_raycastable_graph.html", "interface_pathfinding_1_1_i_raycastable_graph" ],
    [ "IUpdatableGraph", "interface_pathfinding_1_1_i_updatable_graph.html", "interface_pathfinding_1_1_i_updatable_graph" ],
    [ "NNConstraint", "class_pathfinding_1_1_n_n_constraint.html", "class_pathfinding_1_1_n_n_constraint" ],
    [ "NNInfo", "struct_pathfinding_1_1_n_n_info.html", "struct_pathfinding_1_1_n_n_info" ],
    [ "PathNNConstraint", "class_pathfinding_1_1_path_n_n_constraint.html", "class_pathfinding_1_1_path_n_n_constraint" ],
    [ "PathThreadInfo", "struct_pathfinding_1_1_path_thread_info.html", "struct_pathfinding_1_1_path_thread_info" ],
    [ "Progress", "struct_pathfinding_1_1_progress.html", "struct_pathfinding_1_1_progress" ],
    [ "TagMask", "class_pathfinding_1_1_tag_mask.html", "class_pathfinding_1_1_tag_mask" ],
    [ "UserConnection", "class_pathfinding_1_1_user_connection.html", "class_pathfinding_1_1_user_connection" ],
    [ "ConnectionType", "astarclasses_8cs.html#aa1f0e2efd52935fd01bfece0fbead81f", [
      [ "Connection", "astarclasses_8cs.html#aa1f0e2efd52935fd01bfece0fbead81f", null ],
      [ "ModifyNode", "astarclasses_8cs.html#aa1f0e2efd52935fd01bfece0fbead81f", null ]
    ] ],
    [ "GraphDebugMode", "astarclasses_8cs.html#acc4ece232148a2c35ba5ae7a49b2320a", [
      [ "Areas", "astarclasses_8cs.html#acc4ece232148a2c35ba5ae7a49b2320a", null ],
      [ "G", "astarclasses_8cs.html#acc4ece232148a2c35ba5ae7a49b2320a", null ],
      [ "H", "astarclasses_8cs.html#acc4ece232148a2c35ba5ae7a49b2320a", null ],
      [ "F", "astarclasses_8cs.html#acc4ece232148a2c35ba5ae7a49b2320a", null ],
      [ "Penalty", "astarclasses_8cs.html#acc4ece232148a2c35ba5ae7a49b2320a", null ],
      [ "Connections", "astarclasses_8cs.html#acc4ece232148a2c35ba5ae7a49b2320a", null ],
      [ "Tags", "astarclasses_8cs.html#acc4ece232148a2c35ba5ae7a49b2320a", null ]
    ] ],
    [ "GraphUpdateThreading", "astarclasses_8cs.html#a5e43078388e5aff95ebf8f8ba96df16f", [
      [ "UnityThread", "astarclasses_8cs.html#a5e43078388e5aff95ebf8f8ba96df16f", null ],
      [ "SeparateThread", "astarclasses_8cs.html#a5e43078388e5aff95ebf8f8ba96df16f", null ],
      [ "SeparateAndUnityInit", "astarclasses_8cs.html#a5e43078388e5aff95ebf8f8ba96df16f", null ]
    ] ],
    [ "Heuristic", "astarclasses_8cs.html#a35d651e776fc105830877a30b2c7da6a", [
      [ "Manhattan", "astarclasses_8cs.html#a35d651e776fc105830877a30b2c7da6a", null ],
      [ "DiagonalManhattan", "astarclasses_8cs.html#a35d651e776fc105830877a30b2c7da6a", null ],
      [ "Euclidean", "astarclasses_8cs.html#a35d651e776fc105830877a30b2c7da6a", null ],
      [ "None", "astarclasses_8cs.html#a35d651e776fc105830877a30b2c7da6a", null ]
    ] ],
    [ "PathCompleteState", "astarclasses_8cs.html#a8d64a58b1047a9f86a25bed47fef1ad0", [
      [ "NotCalculated", "astarclasses_8cs.html#a8d64a58b1047a9f86a25bed47fef1ad0", null ],
      [ "Error", "astarclasses_8cs.html#a8d64a58b1047a9f86a25bed47fef1ad0", null ],
      [ "Complete", "astarclasses_8cs.html#a8d64a58b1047a9f86a25bed47fef1ad0", null ],
      [ "Partial", "astarclasses_8cs.html#a8d64a58b1047a9f86a25bed47fef1ad0", null ]
    ] ],
    [ "PathLog", "astarclasses_8cs.html#a9ff680067b3de62925a8234fc7da49cb", [
      [ "None", "astarclasses_8cs.html#a9ff680067b3de62925a8234fc7da49cb", null ],
      [ "Normal", "astarclasses_8cs.html#a9ff680067b3de62925a8234fc7da49cb", null ],
      [ "Heavy", "astarclasses_8cs.html#a9ff680067b3de62925a8234fc7da49cb", null ],
      [ "InGame", "astarclasses_8cs.html#a9ff680067b3de62925a8234fc7da49cb", null ],
      [ "OnlyErrors", "astarclasses_8cs.html#a9ff680067b3de62925a8234fc7da49cb", null ]
    ] ],
    [ "PathState", "astarclasses_8cs.html#a3041c83c75eb0c59c5f88d3d40596e1c", [
      [ "Created", "astarclasses_8cs.html#a3041c83c75eb0c59c5f88d3d40596e1c", null ],
      [ "PathQueue", "astarclasses_8cs.html#a3041c83c75eb0c59c5f88d3d40596e1c", null ],
      [ "Processing", "astarclasses_8cs.html#a3041c83c75eb0c59c5f88d3d40596e1c", null ],
      [ "ReturnQueue", "astarclasses_8cs.html#a3041c83c75eb0c59c5f88d3d40596e1c", null ],
      [ "Returned", "astarclasses_8cs.html#a3041c83c75eb0c59c5f88d3d40596e1c", null ]
    ] ],
    [ "ThreadCount", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", [
      [ "AutomaticLowLoad", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "AutomaticHighLoad", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "None", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "One", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "Two", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "Three", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "Four", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "Five", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "Six", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "Seven", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ],
      [ "Eight", "astarclasses_8cs.html#a7f09eccc3b88b84a34a5bc63bdcf8a12", null ]
    ] ],
    [ "GetNextTargetDelegate", "astarclasses_8cs.html#a2a9f5fc2fdb309784b9e8a0b2b4580e0", null ],
    [ "NodeDelegate", "astarclasses_8cs.html#a5d1039bba4534d11950bb8c05738cd0a", null ],
    [ "OnGraphDelegate", "astarclasses_8cs.html#aa32de69d723b2a883314b06f17c7416b", null ],
    [ "OnPathDelegate", "astarclasses_8cs.html#a21c34152c8c7af1c431e9dcc09be0cc1", null ],
    [ "OnScanDelegate", "astarclasses_8cs.html#aae0f2bc7ba2c0c62f79c243341791e53", null ],
    [ "OnScanStatus", "astarclasses_8cs.html#a96e6c4984d36b1d87adae4a409c168c2", null ],
    [ "OnVoidDelegate", "astarclasses_8cs.html#a1822cf403d27bc11962f16d178faf270", null ]
];