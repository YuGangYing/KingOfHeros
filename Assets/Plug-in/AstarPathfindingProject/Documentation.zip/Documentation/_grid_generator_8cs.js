var _grid_generator_8cs =
[
    [ "ASTAR_GRID_CUSTOM_CONNECTIONS", "_grid_generator_8cs.html#a77137b705747d7d030ae0bbc6add45a1", null ],
    [ "NumNeighbours", "_grid_generator_8cs.html#a9077b9ee1d1fd566298b92c2fba75b4a", [
      [ "Four", "_grid_generator_8cs.html#a9077b9ee1d1fd566298b92c2fba75b4a", null ],
      [ "Eight", "_grid_generator_8cs.html#a9077b9ee1d1fd566298b92c2fba75b4a", null ]
    ] ]
];