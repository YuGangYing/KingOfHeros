var _voxel_classes_8cs =
[
    [ "CompactVoxelCell", "struct_pathfinding_1_1_voxels_1_1_compact_voxel_cell.html", "struct_pathfinding_1_1_voxels_1_1_compact_voxel_cell" ],
    [ "CompactVoxelSpan", "struct_pathfinding_1_1_voxels_1_1_compact_voxel_span.html", "struct_pathfinding_1_1_voxels_1_1_compact_voxel_span" ],
    [ "ExtraMesh", "struct_pathfinding_1_1_voxels_1_1_extra_mesh.html", "struct_pathfinding_1_1_voxels_1_1_extra_mesh" ],
    [ "LinkedVoxelSpan", "struct_pathfinding_1_1_voxels_1_1_linked_voxel_span.html", "struct_pathfinding_1_1_voxels_1_1_linked_voxel_span" ],
    [ "VoxelArea", "class_pathfinding_1_1_voxels_1_1_voxel_area.html", "class_pathfinding_1_1_voxels_1_1_voxel_area" ],
    [ "VoxelCell", "struct_pathfinding_1_1_voxels_1_1_voxel_cell.html", "struct_pathfinding_1_1_voxels_1_1_voxel_cell" ],
    [ "VoxelContour", "struct_pathfinding_1_1_voxels_1_1_voxel_contour.html", "struct_pathfinding_1_1_voxels_1_1_voxel_contour" ],
    [ "VoxelContourSet", "class_pathfinding_1_1_voxels_1_1_voxel_contour_set.html", "class_pathfinding_1_1_voxels_1_1_voxel_contour_set" ],
    [ "VoxelMesh", "struct_pathfinding_1_1_voxels_1_1_voxel_mesh.html", "struct_pathfinding_1_1_voxels_1_1_voxel_mesh" ],
    [ "VoxelSerializeUtility", "class_pathfinding_1_1_voxels_1_1_voxel_serialize_utility.html", "class_pathfinding_1_1_voxels_1_1_voxel_serialize_utility" ],
    [ "VoxelSpan", "class_pathfinding_1_1_voxels_1_1_voxel_span.html", "class_pathfinding_1_1_voxels_1_1_voxel_span" ],
    [ "ASTAR_RECAST_ARRAY_BASED_LINKED_LIST", "_voxel_classes_8cs.html#a08de962f8c93ed001a0762116c8af372", null ]
];