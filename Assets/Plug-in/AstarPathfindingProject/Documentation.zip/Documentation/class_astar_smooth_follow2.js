var class_astar_smooth_follow2 =
[
    [ "LateUpdate", "class_astar_smooth_follow2.html#a730d6a2e936437a95bb66aadf86e934b", null ],
    [ "damping", "class_astar_smooth_follow2.html#a99d817470e9063f458d39529c7c1724b", null ],
    [ "distance", "class_astar_smooth_follow2.html#a06f14a9abd47b91465f895d5259cdc1b", null ],
    [ "followBehind", "class_astar_smooth_follow2.html#adb5653ca4c704244f18792419b625acd", null ],
    [ "height", "class_astar_smooth_follow2.html#a48083b65ac9a863566dc3e3fff09a5b4", null ],
    [ "rotationDamping", "class_astar_smooth_follow2.html#a2aff0fc619720960ebfdc2d731327179", null ],
    [ "smoothRotation", "class_astar_smooth_follow2.html#ae285c751113aa05c2fd5bb77f2cffcab", null ],
    [ "staticOffset", "class_astar_smooth_follow2.html#ad84546b76e65b2f46aa9813f9ea9924f", null ],
    [ "target", "class_astar_smooth_follow2.html#a8a24b37582e07ee23646b165d54fa600", null ]
];