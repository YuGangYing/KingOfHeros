var class_custom_graph_editor =
[
    [ "CustomGraphEditor", "class_custom_graph_editor.html#a90a4a950a483ae546a4cfdc3616eaf00", null ],
    [ "displayName", "class_custom_graph_editor.html#aa782ccbdf1d5af49aae11b97a526d56a", null ],
    [ "editorType", "class_custom_graph_editor.html#acd47ff7ceea718b38ee71faab2de809f", null ],
    [ "graphType", "class_custom_graph_editor.html#a89ce7ffcb2fd367df77183e25e613041", null ]
];